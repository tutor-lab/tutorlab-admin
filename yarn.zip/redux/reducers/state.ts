export interface ActionProps {
  type: string;
}

export interface CounterState {
  value: number;
}
